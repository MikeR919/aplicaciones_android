package com.example.act15;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.*;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private Button mApie, mApul, mAyar;
    private TextView resultado;
    private EditText ingreso;
    double resultPrev;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mApie = findViewById(R.id.mApie);
        mApul = findViewById(R.id.mApul);
        mAyar = findViewById(R.id.mAyar);
        resultado = findViewById(R.id.resultado);
        ingreso = findViewById(R.id.ingreso);


        mApie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double cantidad = Double.parseDouble(ingreso.getText().toString());
                resultPrev = (cantidad * 3.28084);
                resultado.setText(String.valueOf(resultPrev));
            }
        });

        mApul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double cantidad = Double.parseDouble(ingreso.getText().toString());
                resultPrev = (cantidad * 39.37008);
                resultado.setText(String.valueOf(resultPrev));
            }
        });

        mAyar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double cantidad = Double.parseDouble(ingreso.getText().toString());
                resultPrev = (cantidad * 1.0936133333333);
                resultado.setText(String.valueOf(resultPrev));
            }
        });
    }
}
